# 05 — Frontend UI

## 1. Stack & outils

| Outil | Configuration |
|-------|---------------|
| Vite | Port 3000, alias `@/` → `src/` |
| TypeScript | Mode strict activé |
| Sass | `src/styles/scss/main.scss` |
| Proxy | `/api` → `http://127.0.0.1:8000` |

## 2. Routing

### Routes publiques

| Route | Page | Description |
|-------|------|-------------|
| `/login` | LoginPage (Bootstrap) | Connexion |
| `/register` | RegisterPage (MUI) | Inscription |
| `/inscription` | InscriptionPubliquePage | Candidature en ligne |
| `/suivi-dossier` | SuiviDossierPage | Suivi candidature |
| `/bootstrap` | BootstrapDemo | Démo composants |

### Routes Bootstrap (non protégées actuellement)

Préfixe selon rôle dans l'URL :

#### Admin (`/admin/*`) — 40+ routes

- Dashboard, référentiel (universités → matières)
- Étudiants (liste, dossiers, inscriptions, documents)
- Évaluations (sessions, examens, notes, délibérations, bulletins)
- Emploi du temps (planning, salles, réservations)
- Finances (factures, paiements, frais)
- Paramétrage, administration, LMD, stages

#### Enseignant (`/enseignant/*`)

- Dashboard + placeholders (cours, notes, présences…)

#### Étudiant (`/etudiant/*`)

- Dashboard + placeholders (profil, notes, bulletins, EDT…)

### Routes MUI legacy (protégées par `ProtectedRoute`)

40+ routes sous `Layout` MUI : `/dashboard`, `/etudiants`, `/sessions`, etc.

### Redirections

- `/` → `/admin/dashboard`
- `/dashboard` → `/admin/dashboard`
- `*` → `/admin/dashboard`

## 3. Authentification frontend

### Flux legacy (MUI) — fonctionnel

```
LoginPage MUI / RegisterPage
  → authStore.login()
    → authService.login() → POST /api/v1/auth/login
      → JWT → localStorage
        → api.ts interceptor ajoute Bearer
          → ProtectedRoute vérifie isAuthenticated
```

### Flux Bootstrap — démo uniquement ⚠️

```
LoginPage Bootstrap
  → setTimeout simulé
    → token fake en localStorage
      → redirect selon email (admin/enseignant/etudiant)
        → PAS d'appel API réel
```

**Impact** : L'utilisateur accède à `/admin/*` sans authentification backend valide.

### Store Zustand (`authStore.ts`)

- `user`, `token`, `isAuthenticated`, `isLoading`
- `login`, `logout`, `loadUser`, `register`
- Persistance token via `localStorage`

## 4. Services API (51 fichiers)

Organisation par domaine dans `src/services/` :

```typescript
// Exemple — src/services/api.ts
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL });
api.interceptors.request.use(/* Bearer token */);
api.interceptors.response.use(/* 401 → logout */);
```

Barrel export partiel dans `services/index.ts` — certains services importés directement.

## 5. Composants UI

### Bootstrap (migration)

- `components/layouts/` — AdminLayout, Sidebar, Header
- `components/ui/` — DataTable, ConfirmModal, EmptyState, Badge
- `pages/bootstrap/` — pages par module

### MUI (legacy)

- `components/Layout.tsx` — AppBar + Drawer
- `components/*/` — formulaires, listes par entité
- `@mui/x-data-grid` — grilles de données
- `@mui/x-date-pickers` — sélecteurs date

## 6. State management

| Store | Usage |
|-------|-------|
| `authStore` | Authentification |
| `useAppStore` | Contexte global (année académique sélectionnée, etc.) |

Hooks métier : `useAuth`, `useFinances`, etc.

## 7. Build & performance

Résultat build production :

| Métrique | Valeur |
|----------|--------|
| JS bundle | ~2.5 Mo (677 Ko gzip) |
| CSS | ~328 Ko (49 Ko gzip) |
| Modules transformés | 14 290 |

⚠️ Recommandation : code-splitting par route (`React.lazy`).

## 8. Tests frontend

| Type | Fichiers | Framework |
|------|----------|-----------|
| Unitaires | 12 | Jest + Testing Library |
| E2E | 6 | Cypress 15 |

Couverture Jest cible : 70% (configurée dans `jest.config.js`).

MSW (`src/__mocks__/handlers.ts`) pour mocker l'API en tests.

## 9. Conventions de code

- Path alias : `@/components/...`
- Types dans `src/types/`
- Formatters dans `src/utils/formatters.ts`
- Gestion erreurs : `src/utils/errorHandler.ts`

## 10. Migration Bootstrap — état

| Zone | Progression estimée |
|------|---------------------|
| Layouts & navigation | ✅ |
| Dashboard admin | ✅ |
| Référentiel | ✅ |
| Étudiants | ✅ |
| Évaluations | ✅ |
| Finances | ✅ |
| Portail enseignant | 🔶 Placeholders |
| Portail étudiant | 🔶 Placeholders |
| Auth unifiée | ❌ |
| Retrait MUI | ❌ |
