# 07 — Modules Fonctionnels

## 1. Organisation pédagogique (Référentiel)

**Objectif** : Structurer l'offre de formation LMD.

### Fonctionnalités

- CRUD universités, établissements, départements
- Gestion cycles (L/M/D), filières, niveaux
- Modules (UE) et matières (EC) avec coefficients
- Années scolaires et années académiques

### API

`/universites`, `/etablissements`, `/departements`, `/cycles`, `/filieres`, `/niveaux`, `/modules`, `/matieres`

### UI

- Bootstrap : `/admin/referentiel/*`
- Legacy : `/universites`, `/filieres`, etc.

---

## 2. Gestion des étudiants

**Objectif** : Dossier étudiant complet.

### Fonctionnalités

- Création fiche étudiant (matricule auto)
- Upload photo et documents
- Consultation inscriptions et parcours
- Recherche, filtres par filière/niveau

### API

`/etudiants`, `/documents-etudiant`

### UI

- `/admin/etudiants/*`, `/etudiants` (legacy)

---

## 3. Inscriptions

**Objectif** : Inscrire les étudiants administrativement et pédagogiquement.

### Sous-modules

| Sous-module | Description |
|-------------|-------------|
| Inscriptions admin | Inscription individuelle/groupe |
| Campagnes | Périodes d'inscription configurables |
| Inscription publique | Portail candidat en ligne |
| Inscription matières | Choix EC par semestre |
| Paiements inscription | Frais dossier |

### API

`/inscriptions`, `/campagnes-inscription`, `/inscription-publique`, `/inscription-groupe`, `/inscriptions-matieres`, `/paiements`

### UI

- Admin : `/admin/etudiants/inscriptions`, `/campagnes`
- Public : `/inscription`, `/suivi-dossier`

---

## 4. Évaluations & résultats

**Objectif** : Gérer le cycle complet des notes et délibérations.

### Workflow

```
Session examen → Examens → Saisie notes → Calcul résultats
  → Délibération → Validation → Bulletins PDF
```

### Fonctionnalités

- Sessions (normale, rattrapage)
- Saisie notes par enseignant
- Calcul moyennes (règles configurables)
- Conseils de délibération
- Génération bulletins semestre/année

### API

`/sessions-examen`, `/examens`, `/notes`, `/resultats`, `/deliberations`, `/bulletins`

### UI

- `/admin/evaluations/*`, `/sessions` (legacy)

---

## 5. Emploi du temps & présences

**Objectif** : Planifier cours et suivre assiduité.

### Fonctionnalités

- Bâtiments et salles
- Créneaux horaires
- Grilles emploi du temps
- Réservation salles
- Feuilles de présence
- Export Excel/PDF EDT

### API

`/batiments`, `/salles`, `/creneaux-horaires`, `/seances`, `/emplois-temps`, `/presences`, `/reservations-salles`

---

## 6. Finances scolarité

**Objectif** : Facturation et suivi des paiements.

### Fonctionnalités

- Types de frais et barèmes par niveau
- Génération factures
- Enregistrement paiements
- Compte étudiant (solde, mouvements)
- Remises et échéanciers
- Reçus PDF

### API

`/types-frais`, `/frais-scolarite`, `/factures`, `/paiements-factures`, `/comptes-etudiants`, `/remises`, `/echeanciers`

### UI

- `/admin/finances/*`, `/paiements-admin` (legacy)

---

## 7. Gestion années académiques LMD

**Objectif** : Piloter le cycle annuel.

### Processus

1. Création année (brouillon)
2. Ouverture + reconduction référentiel
3. Gestion semestres S1/S2
4. Clôture semestres → délibérations
5. Clôture année → archivage

Documentation détaillée : `docs/GESTION_ANNEES.md`

### API

`/annees-academiques`, `/semestres`, `/modules-systeme`

---

## 8. Stages & soutenances

**Objectif** : Suivre stages professionnels et soutenances.

### Fonctionnalités

- Fiche stage (entreprise, tuteur, dates)
- Évaluation stage
- Planification soutenances
- Jury et résultats

Documentation : `docs/STAGES_SOUTENANCES.md`

### API

`/stages`, `/soutenances`

---

## 9. Paramétrage & administration

### Paramétrage établissement

- Paramètres système (clé/valeur)
- Configuration établissement (logo, infos)
- Barèmes notation et mentions
- Templates documents (HTML → PDF)
- Règles de calcul
- Modèles email/SMS
- Configurations par pays

### Administration

- Gestion utilisateurs et rôles
- Modules système activables
- Logs (UI placeholder)

### API

`/parametres`, `/configurations`, `/baremes`, `/templates`, `/regles-calcul`, `/modeles-communication`, `/pays`, `/users`, `/modules-systeme`

---

## 10. Portails par rôle

| Portail | Route | État |
|---------|-------|------|
| Admin / Scolarité | `/admin/*` | ✅ Fonctionnel |
| Enseignant | `/enseignant/*` | 🔶 Structure seule |
| Étudiant | `/etudiant/*` | 🔶 Structure seule |
| Candidat | `/inscription` | ✅ Fonctionnel |

---

## 11. Matrice droits d'accès (cible)

| Action | Admin | Scolarité | Enseignant | Étudiant |
|--------|-------|-----------|------------|----------|
| Référentiel CRUD | ✅ | ❌ | ❌ | ❌ |
| Étudiants CRUD | ✅ | ✅ | 👁️ | 👁️ soi |
| Saisie notes | ✅ | ✅ | ✅ | ❌ |
| Délibérations | ✅ | ✅ | ❌ | ❌ |
| Finances | ✅ | ✅ | ❌ | 👁️ soi |
| Paramétrage | ✅ | ❌ | ❌ | ❌ |

👁️ = lecture seule — **À implémenter côté frontend Bootstrap**
