# Audit Complet — GestSco v2

**Date de l'audit** : 18/08/2026  
**Environnement** : Windows 10, Python 3.12.9, Node 20.20, PostgreSQL 18

---

## Synthèse exécutive

| Domaine | Score | Verdict |
|---------|-------|---------|
| **Backend runtime** | 8/10 | Opérationnel (API + DB connectée) |
| **Frontend runtime** | 7/10 | Opérationnel (build OK, dual-stack UI) |
| **Tests automatisés** | 4/10 | Insuffisants, suite partiellement cassée |
| **Documentation** | 6/10 | README + docs métier, conception v1 obsolète |
| **Qualité code / dette** | 5/10 | Duplication auth, migrations absentes |
| **Sécurité** | 5/10 | JWT OK côté legacy, routes Bootstrap non protégées |
| **Couverture fonctionnelle** | 8/10 | 60 modèles, 54 modules API, UI riche |

**Verdict global** : Le projet est **utilisable en développement** et couvre un périmètre fonctionnel très large, mais **n'est pas prêt pour la production** sans corrections sur les tests, la sécurité frontend, les migrations DB et les dépendances PDF.

---

## 1. Vérifications runtime effectuées

| Vérification | Résultat |
|--------------|----------|
| `GET /health` | ✅ `healthy`, `database: connected` |
| Frontend `npm run dev` | ✅ Port 3000 |
| Frontend `npm run build` | ✅ Build réussi (46s, bundle ~2.5 Mo) |
| Backend import app | ✅ OK (après install pandas/openpyxl) |
| PostgreSQL `gestscov2` | ✅ Existe, tables créées via `init_db.py` |
| Super utilisateur | ✅ `admin@gestsco.com` créé |

---

## 2. Résultats des tests

### Backend — Pytest (48 tests)

```
17 passed | 14 failed | 17 errors
Durée : ~57s
```

| Fichier | Résultat | Cause principale |
|---------|----------|------------------|
| `test_auth.py` | ✅ 11/11 | — |
| `test_api_universites.py` | ❌ 2/19 | Fixture `admin_token` : `no such table: users` (SQLite test DB non initialisée avec tous les modèles) |
| `test_repositories.py` | ❌ 6/18 | Même problème : tables manquantes dans la DB de test |

**Diagnostic** : Les tests universités/repos n'importent pas tous les modèles avant `create_all()`. Les tests auth fonctionnent car ils importent explicitement `User`.

### Frontend — Jest (76 tests)

```
75 passed | 1 failed
12 suites (11 pass, 1 fail)
Durée : ~15s
```

| Échec | Fichier | Cause |
|-------|---------|-------|
| Filtres étudiants | `EtudiantsListPage.test.tsx` | Timeout/chargement async — texte « Toutes les filières » absent au moment de l'assertion |

### Frontend — Cypress

6 specs e2e présents (`auth`, `navigation`, `referentiel`, `etudiants`, `finances`, `administration`) — **non exécutés** durant cet audit (nécessitent serveur + DB).

### Lint

| Outil | Statut |
|-------|--------|
| `npm run lint` | ❌ ESLint absent de `devDependencies`, pas de config |
| TypeScript strict | ✅ Build `tsc` passe |

---

## 3. Architecture — constats

### Points forts

- Architecture 3-tiers claire : React SPA ↔ FastAPI REST ↔ PostgreSQL
- Pattern **Repository + Service** côté backend
- **60 entités SQLAlchemy** couvrant tout le métier scolarité
- **54 fichiers endpoints** montés sous `/api/v1`
- **51 services API** frontend alignés sur le backend
- Documentation Swagger auto-générée (`/docs`)
- Double UI en migration (MUI legacy + Bootstrap nouveau)

### Problèmes identifiés

#### Critique (P0)

| # | Problème | Impact |
|---|----------|--------|
| 1 | Routes Bootstrap (`/admin/*`) **sans authentification** | Accès non contrôlé à l'interface admin |
| 2 | `LoginPage` Bootstrap = **mode démo** (token fake) | Pas de vraie connexion sur le flux principal |
| 3 | Alembic configuré mais **0 migration** dans `alembic/versions/` | Pas de versioning schéma en production |
| 4 | Suite de tests backend **65% en échec/erreur** | Régression non détectable |

#### Important (P1)

| # | Problème | Impact |
|---|----------|--------|
| 5 | Double stack DI : `deps.py` vs `dependencies.py` | Incohérence auth/tests |
| 6 | Deux routers `/annees-academiques` | Risque conflit routes |
| 7 | `reportlab` et `weasyprint` **absents** de requirements | PDF bulletins/factures en fallback |
| 8 | Pas de CI/CD (`.github/workflows` absent) | Pas d'intégration continue |
| 9 | Bundle JS **2.5 Mo** (pas de code-splitting) | Performance chargement |

#### Mineur (P2)

| # | Problème |
|---|----------|
| 10 | Warnings Pydantic V2 (`class Config` deprecated) |
| 11 | `datetime.utcnow()` deprecated |
| 12 | Sass `@import` deprecated (Bootstrap) |
| 13 | Script `create_annee_scolaire_table.py` importe `AnneeScolaire` (classe = `Annee`) |
| 14 | `babel-jest` référencé mais absent |
| 15 | Couverture tests ~5% du code backend |

---

## 4. Inventaire technique

### Backend

```
backend/
├── app/
│   ├── api/v1/endpoints/     47 modules
│   ├── api/endpoints/         7 modules (paramétrage legacy)
│   ├── models/               60 entités
│   ├── schemas/              ~50 schémas Pydantic
│   ├── services/             ~25 services métier
│   ├── repositories/         ~40 repositories
│   └── core/                 config, security, database, init_db
├── scripts/                  16 utilitaires dev
├── app/scripts/              11 scripts seed/init
├── tests/                    3 fichiers (48 tests)
└── alembic/                  config sans versions
```

### Frontend

```
frontend/src/
├── pages/                    Legacy MUI + bootstrap/
├── components/               MUI (~138 fichiers) + Bootstrap (~85)
├── services/                 51 services API
├── store/                    Zustand (authStore, useAppStore)
├── routes/BootstrapRoutes.tsx
└── __tests__/ + cypress/e2e/
```

---

## 5. Matrice modules fonctionnels vs implémentation

| Module | Backend API | Frontend UI | Tests |
|--------|-------------|-------------|-------|
| Auth / Users | ✅ | ⚠️ Demo login Bootstrap | ✅ Auth |
| Référentiel (univ→matières) | ✅ | ✅ MUI + Bootstrap | ⚠️ Partiel |
| Étudiants | ✅ | ✅ | ⚠️ 1 test Jest fail |
| Inscriptions / Campagnes | ✅ | ✅ | ❌ |
| Inscription publique | ✅ | ✅ | ❌ |
| Évaluations / Notes | ✅ | ✅ | ❌ |
| Délibérations / Bulletins | ✅ | ✅ | ❌ |
| Emploi du temps | ✅ | ✅ | ❌ |
| Finances / Factures | ✅ | ✅ | ⚠️ Tests unitaires finances |
| Paramétrage | ✅ | ✅ | ❌ |
| Années académiques LMD | ✅ | ✅ | ❌ |
| Stages / Soutenances | ✅ | ✅ | ❌ |
| Modules système | ✅ | ✅ | ❌ |

---

## 6. Dépendances — état

### Backend (`requirements.txt`)

| Package | Statut |
|---------|--------|
| fastapi, uvicorn, sqlalchemy, pydantic | ✅ |
| pandas, openpyxl | ✅ (ajouté récemment) |
| bcrypt `<5` | ✅ (compat passlib) |
| reportlab | ❌ Manquant (PDF) |
| weasyprint | ❌ Manquant (templates PDF) |

### Frontend (`package.json`)

| Package | Statut |
|---------|--------|
| react, vite, typescript | ✅ |
| @mui/material + react-bootstrap | ✅ (dual stack) |
| eslint | ❌ Manquant |
| babel-jest | ❌ Manquant (référencé dans jest.config) |

---

## 7. Recommandations immédiates

1. **Unifier l'authentification** : connecter `LoginPage` Bootstrap à `authService` + `ProtectedRoute` sur BootstrapRoutes
2. **Corriger les tests backend** : `conftest.py` global avec import de tous les modèles + SQLite
3. **Initialiser Alembic** : `alembic revision --autogenerate` + corriger imports dans `env.py`
4. **Ajouter reportlab** aux requirements (optionnel weasyprint)
5. **Mettre en place CI** : pytest + jest + build sur chaque PR
6. **Code-splitting Vite** : réduire le bundle initial

Voir [11_PLAN_ACTION.md](./11_PLAN_ACTION.md) pour la roadmap détaillée.
