# 11 — Plan d'Action & Roadmap

## 1. Priorisation

| Priorité | Délai | Thème |
|----------|-------|-------|
| **P0** | Immédiat | Sécurité, tests cassés |
| **P1** | 2-4 semaines | Qualité, migrations, deps |
| **P2** | 1-3 mois | Migration UI, portails |
| **P3** | 3-6 mois | Production, CI/CD, Docker |

---

## 2. P0 — Bloquants (immédiat)

### 2.1 Authentification Bootstrap

**Problème** : LoginPage démo + routes admin ouvertes.

**Actions** :
- [ ] Refactorer `LoginPage` Bootstrap → appeler `authService.login()`
- [ ] Envelopper `BootstrapRoutes` dans `ProtectedRoute`
- [ ] Rediriger `/login` si token invalide sur routes protégées
- [ ] Tests e2e auth sur flux Bootstrap

**Effort** : 1-2 jours

### 2.2 Corriger suite tests backend

**Problème** : 31/48 tests en échec/erreur.

**Actions** :
- [ ] Créer `tests/conftest.py` avec import complet des modèles
- [ ] Unifier override `get_db` pour tous les tests
- [ ] Vérifier `pytest` → 48/48 pass

**Effort** : 0.5-1 jour

### 2.3 Secret & credentials production

**Actions** :
- [ ] Documenter génération SECRET_KEY
- [ ] Script post-init : forcer changement mot de passe admin
- [ ] Vérifier `.env` dans `.gitignore`

**Effort** : 0.5 jour

---

## 3. P1 — Qualité (2-4 semaines)

### 3.1 Migrations Alembic

- [ ] Corriger `alembic/env.py` → `import app.models`
- [ ] `alembic revision --autogenerate -m "initial"`
- [ ] Documenter workflow migration dans README backend
- [ ] Retirer dépendance à `create_all()` en production

### 3.2 Dépendances manquantes

- [ ] Ajouter `reportlab` à requirements.txt (PDF)
- [ ] Évaluer `weasyprint` (lourd, dépendances système)
- [ ] Ajouter ESLint + config frontend
- [ ] Retirer ou ajouter `babel-jest`

### 3.3 Unifier auth backend

- [ ] Migrer endpoints `dependencies.py` → `deps.py`
- [ ] Supprimer doublon `AuthService` vs inline JWT
- [ ] Un seul point de vérité pour `get_current_user`

### 3.4 Résoudre conflit routes

- [ ] Fusionner `annees_academiques.py` et `annees_academiques_gestion.py`
- [ ] Ou séparer préfixes (`/annees-academiques` vs `/gestion-annees`)

### 3.5 CI/CD

- [ ] GitHub Actions : pytest + jest + build
- [ ] Badge status dans README racine

---

## 4. P2 — Fonctionnel (1-3 mois)

### 4.1 Finaliser migration Bootstrap

- [ ] Portail enseignant fonctionnel (notes, EDT, présences)
- [ ] Portail étudiant fonctionnel (notes, bulletins, EDT)
- [ ] Retirer pages MUI legacy
- [ ] Retirer dépendances MUI (~138 fichiers)

### 4.2 RBAC frontend

- [ ] Matrice permissions par rôle
- [ ] Masquer menus/actions selon rôle
- [ ] Guard routes enseignant/étudiant

### 4.3 Étendre couverture tests

- [ ] Tests API : inscriptions, notes, factures
- [ ] Tests services frontend critiques
- [ ] Cypress en CI

### 4.4 Performance frontend

- [ ] Code-splitting routes (`React.lazy`)
- [ ] Réduire bundle < 1 Mo
- [ ] Migrer Sass `@import` → `@use`

---

## 5. P3 — Industrialisation (3-6 mois)

### 5.1 Containerisation

- [ ] Dockerfile backend + frontend
- [ ] docker-compose dev + prod
- [ ] Documentation déploiement Docker

### 5.2 Observabilité

- [ ] Structured logging (JSON)
- [ ] Métriques Prometheus / health détaillé
- [ ] Alerting uptime

### 5.3 Fonctionnalités avancées

- [ ] Refresh token JWT
- [ ] Notifications email/SMS (intégration réelle)
- [ ] Export massif / import référentiel
- [ ] Multi-établissement (si requis)

---

## 6. Roadmap visuelle

```
2026 Q3          Q4              2027 Q1
│                │               │
├─ P0 Sécurité   ├─ Portails     ├─ Docker
├─ P0 Tests      ├─ RBAC         ├─ Monitoring
├─ P1 Alembic    ├─ Retrait MUI  ├─ Notifications
├─ P1 CI/CD      ├─ Tests ++     │
│                │               │
└─ MVP stable    └─ Beta prod    └─ Production
```

---

## 7. Definition of Done — Production

Le projet sera considéré **prêt production** quand :

- [ ] 100% tests backend passent
- [ ] Couverture backend ≥ 60%
- [ ] Couverture frontend ≥ 70%
- [ ] Auth unifiée et routes protégées
- [ ] Migrations Alembic opérationnelles
- [ ] CI/CD vert sur main
- [ ] Audit sécurité passé
- [ ] Documentation ops complète
- [ ] Backup/restore testé
- [ ] Déploiement staging validé par métier

---

## 8. Suivi

| Document | Mise à jour |
|----------|-------------|
| Audit | Après chaque sprint |
| Plan d'action | Mensuel |
| Conception | À chaque module majeur |

**Prochaine revue recommandée** : fin septembre 2026
